#include "rtklib.h"
#include "android.h"
#include "stdlib.h"
#include <winsock2.h>
#include <windows.h>
/*#pragma comment(lib,"ws2_32.lib")  */
static unsigned char U1(unsigned char *p) { unsigned char u; memcpy(&u, p, 1); return u; }
static unsigned short U2(unsigned char *p) { unsigned short u; memcpy(&u, p, 2); return u; }
static unsigned int   U4(unsigned char *p) { unsigned int   u; memcpy(&u, p, 4); return u; }
static int            I4(unsigned char *p) { int            u; memcpy(&u, p, 4); return u; }
static float          R4(unsigned char *p) { float          r; memcpy(&r, p, 4); return r; }
static double         R8(unsigned char *p) { double         r; memcpy(&r, p, 8); return r; }
static long long        L8(unsigned char *p) { long long       r; memcpy(&r, p, 8); return r; }

int flag_cmp(unsigned char svid, unsigned char *flag)
{
	int i=0;
	while (flag[i]!=0)
	{
		if(flag[i] == svid) return 1;
			i++;
	}
	return 0;
}
unsigned char svid2sat(int type, unsigned char svid)
{
	switch (type) {
		case 1: return satno(SYS_GPS, svid);
		case 2: return satno(SYS_SBS, svid);
		case 3: return satno(SYS_GLO, svid);
		case 4:	return satno(SYS_QZS, svid);
		case 5:	return satno(SYS_CMP, svid);
		case 6:	return satno(SYS_GAL, svid);
	}
}
/* Fill obs_t with data from android_clockd_t and andorid_measurements_t */
int convertObservationData(obs_t *obs, android_clockd_t *cl, android_measurements_t *ms) {
  int i,j,n=0,m=0,k=1;
  obsd_t *obsd;
  android_measurementsd_t *android_obs;
  gtime_t rcv_time, sat_time;
  long long msg_time_nanos;
  int rcv_week;
  double sat_tow;
  unsigned char flag[30] = {0};
  trace(3, "converting observation data\n");

  /* Set number of observations */
 // obs->n = ms->n;
  trace(4, "obsd_t.n = %d\n", obs->n);

  /* Calculate GPS time for message */
  msg_time_nanos = cl->timeNanos - cl->fullBiasNanos;
  trace(4, "msg_time_nanos = %ld\n", msg_time_nanos);
 for (int type = 1; type <= 6; type++)   //6��������������δ����unkown
 {
	 n = 0;
	 memset(flag, 0, sizeof(flag));
	   for (i = 0; i < ms->n; i++) {
	 
		  if (ms->measurements[i].constellationType != type) continue;   //��������Ͳ�ͬ������һ������
		  if (flag_cmp(ms->measurements[i].svid, flag))  continue;        //������������Ƕ�Ƶ���ݣ��Ѿ������㣬������

		  flag[n] = ms->measurements[i].svid;  //m�ǲ�ͬ��������ͬƵ�ʵ����ݸ���
		  obsd = &obs->data[m++];  
		  android_obs = &ms->measurements[i];

		  //if(android_obs->svid== ms->measurements[i]->svid)
		  /* === receiver sampling time (GPST) === */
		  rcv_time = nano2gtime(msg_time_nanos + android_obs->timeOffsetNanos);
		  //rcv_time = nano2gtime(msg_time_nanos + android_obs->timeOffsetNanos-FirstCount);//add by lg 20210609
		  obsd->time = rcv_time;
		  /* === satellite/receiver number === */
		  obsd->sat = svid2sat(type,ms->measurements[i].svid);
		  /*if(ms->measurements[i].constellationType==1)
		  printf("1=%d  ", ms->measurements[i].svid);
		  printf("  ");
		  if (ms->measurements[i].constellationType == 2)
			  printf("2=%d  ", ms->measurements[i].svid);
		  printf("  ");
		  if (ms->measurements[i].constellationType == 3)
			  printf("3=%d  ", ms->measurements[i].svid);
		  printf("  ");
		  if (ms->measurements[i].constellationType == 4)
		  printf("4=%d  ", ms->measurements[i].svid);
		  printf("  ");
		  if (ms->measurements[i].constellationType == 5)
			  printf("5=%d  ", ms->measurements[i].svid);
		  printf("  ");
		  if (ms->measurements[i].constellationType == 6)
			  printf("6=%d  ", ms->measurements[i].svid);
		  printf("  ");*/

		  /* Calculate GPST for satellite */
		  /* We only receive satellite TOW from Android, so we use week from rcv_time instead */
		  time2gpst(rcv_time, &rcv_week);  /* Calculate week number */

		  sat_tow = nano2sec(android_obs->receivedSvTimeNanos); /* Calculate time-of-week */   //����ת��

		  sat_time = nano2gtime(rcv_week*WEEK2SEC*SEC2NSEC + android_obs->receivedSvTimeNanos);

		  /* === satellite/receiver number === */
		  /* obsd->rcv      = recId;                    */

		  /* === signal strength (0.25 dBHz) === */
		  obsd->SNR[0] = (uint16_t)((android_obs->cn0DbHz * 4)*1.0/SNR_UNIT+0.5);
		  trace(4, "obsd_t.SNR[0] = %d\n", obsd->SNR[0]);

		  /* === loss of lock indicator === */
		  obsd->LLI[0] = android_obs->state;
		 
		  /* === code indicator (CODE_???) === */
		  obsd->code[0] = CODE_L1C;

		  /* === quality of carrier phase measurement === */
		  obsd->qualL[0] = 0;

		  /* === quality of pseudorange measurement === */
		  obsd->qualP[0] = 0;

		  /* === observation data carrier-phase (cycle) === */
		  //obsd->L[0]     = 0;
		  obsd->L[0] = android_obs->accumulatedDeltaRangeMeters / (CLIGHT / android_obs->carrierFrequencyHz);
		  /*  === observation data pseudorange (m) === */
		  obsd->P[0] = calcPseudoRange(rcv_time, sat_time);

		  /* === observation data doppler frequency (Hz) === */
		  /* obsd->D[0]     = null;                     */
		  obsd->D[0] = -android_obs->pseudorangeRateMetersPerSecond / (CLIGHT / android_obs->carrierFrequencyHz);//LG add 20210601

		  for (j = i + 1; j < ms->n; j++) {
			  if (ms->measurements[j].constellationType != type) continue;
			  
			  if (ms->measurements[j].svid==flag[n])
			  {
				  android_obs = &ms->measurements[j];
				  rcv_time = nano2gtime(msg_time_nanos + android_obs->timeOffsetNanos);
				  //rcv_time = nano2gtime(msg_time_nanos + android_obs->timeOffsetNanos-FirstCount);//add by lg 20210609
				  time2gpst(rcv_time, &rcv_week);  /* Calculate week number */
				  sat_tow = nano2sec(android_obs->receivedSvTimeNanos); /* Calculate time-of-week */   //����ת��
				  sat_time = nano2gtime(rcv_week*WEEK2SEC*SEC2NSEC + android_obs->receivedSvTimeNanos);
				  obsd->SNR[k] = (unsigned char)(android_obs->cn0DbHz * 4);
				  obsd->LLI[k] = android_obs->state;
				  obsd->code[k] = CODE_L2C;
				  obsd->qualL[k] = 0;
				  obsd->qualP[k] = 0;
				  //obsd->L[0]     = 0;
				  obsd->L[k] = android_obs->accumulatedDeltaRangeMeters / (CLIGHT / android_obs->carrierFrequencyHz);//LG add20210601
				  obsd->P[k] = calcPseudoRange(rcv_time, sat_time);
				  /* obsd->D[0]     = null;                     */
				  obsd->D[k] = -android_obs->pseudorangeRateMetersPerSecond / (CLIGHT / android_obs->carrierFrequencyHz);//LG add 20210601
				  k++;
			  }
		  }
		  k = 1;
		  n++;
	   }

  }
  obs->n = m-1;


  return (int) observationData;
}

/* ========= ============ ========= */ 
/* ========= Calculations ========= */ 
/* ========= ============ ========= */ 
double nano2sec(long long t){
  return t/((double)SEC2NSEC);
}

gtime_t nano2gtime(long long nanoSec){
  int week;
  double sec;

  week = nanoSec / (double)SEC2NSEC / (double)WEEK2SEC;
  sec = (nanoSec - week * WEEK2SEC * SEC2NSEC) /  (double)SEC2NSEC;

  return gpst2time(week, sec);
}

double calcPseudoRange(gtime_t rx, gtime_t tx){
  double diff = timediff(rx, tx);
  trace(5, "timediff = %f\n", diff);
  return diff * CLIGHT;
}

void Clock_Mearsurement_Data(android_clockd_t *cl, android_measurements_t *ms, char *str) {
	int i;
	android_measurementsd_t *msd;
	str = str + 6;
	cl->biasNanos=R8(str);
	str += 8;
	cl->biasUncertaintyNanos= R8(str);	
	str += 8;
	cl->driftNanosPerSecond = R8(str);
	str += 8;
	cl->driftUncertaintyNanosPerSecond = R8(str);
	str += 8;
	cl->fullBiasNanos = L8(str);
	str += 8;
	cl->hardwareClockDiscontinuityCount = I4(str);
	str += 4;
	cl->leapSecond == I4(str);
	str += 4;
	cl->timeNanos = L8(str);
	str += 8;
	cl->timeUncertaintyNanos = R8(str);
	str += 8;
	cl->hasBiasNanos = I4(str);
	str += 4;
	cl->hasBiasUncertaintyNanos = I4(str);
	str += 4;
	cl->hasDriftNanosPerSecond = I4(str);
	str += 4;
	cl->hasDriftUncertaintyNanosPerSecond = I4(str);
	str += 4;
	cl->hasFullBiasNanos = I4(str);
	str += 4;
	cl->hasLeapSecond = I4(str);
	str += 4;
	cl->hasTimeUncertaintyNanos = I4(str);
	str += 4;
	ms->n = I4(str);
	str += 4;

	for (i = 0; i < ms->n; i++) {
		msd = &ms->measurements[i];

		msd->accumulatedDeltaRangeMeters = R8(str);
		str += 8;
		msd->accumulatedDeltaRangeState = I4(str);
		str += 4;
		msd->accumulatedDeltaRangeUncertaintyMeters = R8(str);
		str += 8;
		msd->automaticGainControlLevelDbc = R8(str);
		str += 8;
		msd->carrierCycles = L8(str);
		str += 8;
		msd->carrierFrequencyHz = R4(str);
		str += 4;
		msd->carrierPhase = R8(str);
		str += 8;
		msd->carrierPhaseUncertainty = R8(str);
		str += 8;
		msd->cn0DbHz = R8(str);
		str += 8;
		msd->constellationType = I4(str);
		str += 4;
		msd->multipathIndicator = I4(str);
		str += 4;
		msd->pseudorangeRateMetersPerSecond = R8(str);
		str += 8;
		msd->pseudorangeRateUncertaintyMetersPerSecond = R8(str);
		str += 8;
		msd->receivedSvTimeNanos = L8(str);
		str += 8;
		msd->receivedSvTimeUncertaintyNanos = L8(str);
		str += 8;
		msd->snrInDb = R8(str);
		str += 8;
		msd->state = I4(str);
		str += 4;
		msd->svid = I4(str);
		str += 4;
		msd->timeOffsetNanos = R8(str);
		str += 8;
		msd->hasAutomaticGainControlLevelDb = I4(str);
		str += 4;
		msd->hasCarrierCycles = I4(str);
		str += 4;
		msd->hasCarrierFrequencyHz = I4(str);
		str += 4;
		msd->hasCarrierPhase = I4(str);
		str += 4;
		msd->hasCarrierPhaseUncertainty = I4(str);
		str += 4;
		msd->hasSnrInDb = I4(str);
        str += 4;
	}
}
void Clock_Mearsurement_Dataf(android_clockd_t *cl, android_measurements_t *ms, char *str, char *seg) {
	int i;
	android_measurementsd_t *msd;

	char *substr = strtok(str, seg);

	cl->biasNanos = strtod(substr, NULL);
	//printf("%s-->>%f\n", substr, cl->biasNanos);
	substr = strtok(NULL, seg);
	cl->biasUncertaintyNanos = strtod(substr, NULL);
	//printf("%s-->>%f\n", substr, cl->biasUncertaintyNanos);
	substr = strtok(NULL, seg);
	cl->driftNanosPerSecond = strtod(substr, NULL);
	//printf("%s-->>%f\n", substr, cl->driftNanosPerSecond);
	substr = strtok(NULL, seg);
	cl->driftUncertaintyNanosPerSecond = strtod(substr, NULL);
	//printf("%s-->>%f\n", substr, cl->driftUncertaintyNanosPerSecond);
	substr = strtok(NULL, seg);
	cl->fullBiasNanos = atoll(substr);
	//printf("%s-->>%lld\n", substr, cl->fullBiasNanos);
	substr = strtok(NULL, seg);
	cl->hardwareClockDiscontinuityCount = atoi(substr);
	//printf("%s-->>%d\n", substr, cl->hardwareClockDiscontinuityCount);
	substr = strtok(NULL, seg);
	cl->leapSecond = atoi(substr);
	//printf("%s-->>%d\n", substr, cl->leapSecond);
	substr = strtok(NULL, seg);
	cl->timeNanos = atoll(substr);
	//printf("%s-->>%lld\n", substr, cl->timeNanos);
	substr = strtok(NULL, seg);
	cl->timeUncertaintyNanos = strtod(substr, NULL);
	//printf("%s-->>%f\n", substr, cl->timeUncertaintyNanos);
	substr = strtok(NULL, seg);
	cl->hasBiasNanos = atoi(substr);
	//printf("%s-->>%d\n", substr, cl->hasBiasNanos);
	substr = strtok(NULL, seg);
	cl->hasBiasUncertaintyNanos = atoi(substr);
	//printf("%s-->>%d\n", substr, cl->hasBiasUncertaintyNanos);
	substr = strtok(NULL, seg);
	cl->hasDriftNanosPerSecond = atoi(substr);
	//printf("%s-->>%d\n", substr, cl->hasDriftNanosPerSecond);
	substr = strtok(NULL, seg);
	cl->hasDriftUncertaintyNanosPerSecond = atoi(substr);
	//printf("%s-->>%d\n", substr, cl->hasDriftUncertaintyNanosPerSecond);
	substr = strtok(NULL, seg);
	cl->hasFullBiasNanos = atoi(substr);
	//printf("%s-->>%d\n", substr, cl->hasFullBiasNanos);
	substr = strtok(NULL, seg);
	cl->hasLeapSecond = atoi(substr);
	//printf("%s-->>%d\n", substr, cl->hasLeapSecond);
	substr = strtok(NULL, seg);
	cl->hasTimeUncertaintyNanos = atoi(substr);
	//printf("%s-->>%d\n", substr, cl->hasTimeUncertaintyNanos);
	substr = strtok(NULL, seg);

	if (TimeFlag == 0)
	{
		FirstBiasNanos = cl->biasNanos;
		FirstFullBiasNanos = cl->fullBiasNanos;
		FirstCount = FirstBiasNanos + (double)FirstFullBiasNanos;
		TimeFlag = 1;
		//add by lg 20210609
	}
	ms->n = atoi(substr);
	//printf("%s-->>%d\n", substr, ms->n);
	substr = strtok(NULL, seg);
	for (i = 0; i < ms->n; i++) {
		msd = &ms->measurements[i];

		msd->accumulatedDeltaRangeMeters = strtod(substr, NULL);
		//printf("%s-->>%f\n", substr, msd->accumulatedDeltaRangeMeters);
		substr = strtok(NULL, seg);
		msd->accumulatedDeltaRangeState = atoi(substr);
		//printf("%s-->>%d\n", substr, msd->accumulatedDeltaRangeState);
		substr = strtok(NULL, seg);
		msd->accumulatedDeltaRangeUncertaintyMeters = strtod(substr, NULL);
		//printf("%s-->>%f\n", substr, msd->accumulatedDeltaRangeUncertaintyMeters);
		substr = strtok(NULL, seg);
		msd->automaticGainControlLevelDbc = strtod(substr, NULL);
		//printf("%s-->>%f\n", substr, msd->automaticGainControlLevelDbc);
		substr = strtok(NULL, seg);
		msd->carrierCycles = atoll(substr);
		//printf("%s-->>%lld\n", substr, msd->carrierCycles);
		substr = strtok(NULL, seg);
		msd->carrierFrequencyHz = strtof(substr, NULL);
		//printf("%s-->>%f\n", substr, msd->carrierFrequencyHz);
		substr = strtok(NULL, seg);
		msd->carrierPhase = strtod(substr, NULL);
		//printf("%s-->>%f\n", substr, msd->carrierPhase);
		substr = strtok(NULL, seg);
		msd->carrierPhaseUncertainty = strtod(substr, NULL);
		//printf("%s-->>%f\n", substr, msd->carrierPhaseUncertainty);
		substr = strtok(NULL, seg);
		msd->cn0DbHz = strtod(substr, NULL);
		//printf("%s-->>%f\n", substr, msd->cn0DbHz);
		substr = strtok(NULL, seg);
		msd->constellationType = atoi(substr);
		//printf("%s-->>%d\n", substr, msd->constellationType);
		substr = strtok(NULL, seg);
		msd->multipathIndicator = atoi(substr);
		//printf("%s-->>%d\n", substr, msd->multipathIndicator);
		substr = strtok(NULL, seg);
		msd->pseudorangeRateMetersPerSecond = strtod(substr, NULL);
		//printf("%s-->>%f\n", substr, msd->pseudorangeRateMetersPerSecond);
		substr = strtok(NULL, seg);
		msd->pseudorangeRateUncertaintyMetersPerSecond = strtod(substr, NULL);
		//printf("%s-->>%f\n", substr, msd->pseudorangeRateUncertaintyMetersPerSecond);
		substr = strtok(NULL, seg);
		msd->receivedSvTimeNanos = atoll(substr);
		//printf("%s-->>%lld\n", substr, msd->receivedSvTimeNanos);
		substr = strtok(NULL, seg);
		msd->receivedSvTimeUncertaintyNanos = atoll(substr);
		//printf("%s-->>%lld\n", substr, msd->receivedSvTimeUncertaintyNanos);
		substr = strtok(NULL, seg);
		msd->snrInDb = strtod(substr, NULL);
		//printf("%s-->>%f\n", substr, msd->snrInDb);
		substr = strtok(NULL, seg);
		msd->state = atoi(substr);
		//printf("%s-->>%d\n", substr, msd->state);
		substr = strtok(NULL, seg);
		msd->svid = atoi(substr);
		//printf("%s-->>%d\n", substr, msd->svid);
		//printf("%d--",msd->svid);
		substr = strtok(NULL, seg);
		msd->timeOffsetNanos = strtod(substr, NULL);
		//printf("%s-->>%f\n", substr, msd->timeOffsetNanos);
		substr = strtok(NULL, seg);
		msd->hasAutomaticGainControlLevelDb = atoi(substr);
		//printf("%s-->>%d\n", substr, msd->hasAutomaticGainControlLevelDb);
		substr = strtok(NULL, seg);
		msd->hasCarrierCycles = atoi(substr);
		//printf("%s-->>%d\n", substr, msd->hasCarrierCycles);
		substr = strtok(NULL, seg);
		msd->hasCarrierFrequencyHz = atoi(substr);
		//printf("%s-->>%d\n", substr, msd->hasCarrierFrequencyHz);
		substr = strtok(NULL, seg);
		msd->hasCarrierPhase = atoi(substr);
		//printf("%s-->>%d\n", substr, msd->hasCarrierPhase);
		substr = strtok(NULL, seg);
		msd->hasCarrierPhaseUncertainty = atoi(substr);
		//printf("%s-->>%d\n", substr, msd->hasCarrierPhaseUncertainty);
		substr = strtok(NULL, seg);
		msd->hasSnrInDb = atoi(substr);
		//printf("%s-->>%d\n", substr, msd->hasSnrInDb);
		substr = strtok(NULL, seg);
	}
}
/* ========= ============ ========= */ 
/* ========= Parsing      ========= */ 
/* ========= ============ ========= */ 

/* Fill android_clockd_t struct from raw byte sequence */
void parseClockData(android_clockd_t *cl, unsigned char **ptr) {


  trace(4, "parsing clock data\n");
  trace(5, "cl->biasNanos\n");
  cl->biasNanos = readDouble(ptr);//ȡ��һ����Ԫֵ����
  trace(5, "cl->biasUncertaintyNanos\n");
  cl->biasUncertaintyNanos = readDouble(ptr);
  trace(5, "cl->driftNanosPerSecond\n");
  cl->driftNanosPerSecond = readDouble(ptr);
  trace(5, "cl->driftUncertaintyNanosPerSecond\n");
  cl->driftUncertaintyNanosPerSecond = readDouble(ptr);
  trace(5, "cl->fullBiasNanos\n");
  cl->fullBiasNanos = readLong(ptr);//ȡ��һ����Ԫֵ����
  trace(5, "cl->hardwareClockDiscontinuityCount\n");
  cl->hardwareClockDiscontinuityCount = readInt(ptr);
  trace(5, "cl->leapSecond\n");
  cl->leapSecond = readInt(ptr);
  trace(5, "cl->timeNanos\n");
  cl->timeNanos = readLong(ptr);
  trace(5, "cl->timeUncertaintyNanos\n");
  cl->timeUncertaintyNanos = readDouble(ptr);

  trace(5, "cl->hasBiasNanos\n");
  cl->hasBiasNanos = readInt(ptr);
  trace(5, "cl->hasBiasUncertaintyNanos\n");
  cl->hasBiasUncertaintyNanos = readInt(ptr); 
  trace(5, "cl->hasDriftNanosPerSecond\n");
  cl->hasDriftNanosPerSecond = readInt(ptr); 
  trace(5, "cl->hasDriftUncertaintyNanosPerSecond\n");
  cl->hasDriftUncertaintyNanosPerSecond = readInt(ptr); 
  trace(5, "cl->hasFullBiasNanos\n");
  cl->hasFullBiasNanos = readInt(ptr); 
  trace(5, "cl->hasLeapSecond\n");
  cl->hasLeapSecond = readInt(ptr); 
  trace(5, "cl->hasTimeUncertaintyNanos\n");
  cl->hasTimeUncertaintyNanos = readInt(ptr);

  if(TimeFlag==0)
  {
	  FirstBiasNanos=cl->biasNanos;
	  FirstFullBiasNanos= cl->fullBiasNanos;
	  FirstCount=FirstBiasNanos+(double)FirstFullBiasNanos;
	  TimeFlag=1;
	  //add by lg 20210609
  }




}

/* Fill android_measurements_t struct from raw byte sequence */
void parseMeasurementData(android_measurements_t *ms, unsigned char **ptr) {
  int i;
  android_measurementsd_t *msd;

  trace(4, "parsing measurement data\n");

  ms->n = readInt(ptr);

  trace(4, "ms->n = %d\n", ms->n);
  
  for (i = 0; i < ms->n; i++) {
    msd = &ms->measurements[i];
    trace(4, "parsing measurement %d\n", i);

	trace(5, "msd->accumulatedDeltaRangeMeters\n");
	msd->accumulatedDeltaRangeMeters = readDouble(ptr);                        
	trace(5, "msd->accumulatedDeltaRangeState\n");
	msd->accumulatedDeltaRangeState = readInt(ptr);
	trace(5, "msd->accumulatedDeltaRangeUncertaintyMeters\n");
	msd->accumulatedDeltaRangeUncertaintyMeters = readDouble(ptr);
	trace(5, "msd->automaticGainControlLevelDbc\n");
	msd->automaticGainControlLevelDbc = readDouble(ptr);
	trace(5, "msd->carrierCycles\n");
	msd->carrierCycles = readLong(ptr);
	trace(5, "msd->carrierFrequencyHz\n");
	msd->carrierFrequencyHz = readFloat(ptr);
    trace(5, "msd->carrierPhase\n");
    msd->carrierPhase = readDouble(ptr);
    trace(5, "msd->carrierPhaseUncertainty\n");
    msd->carrierPhaseUncertainty = readDouble(ptr);
    trace(5, "msd->cn0DbHz\n");
    msd->cn0DbHz = readDouble(ptr);
    trace(5, "msd->constellationType\n");
    msd->constellationType = readInt(ptr);
    trace(5, "msd->multipathIndicator\n");
    msd->multipathIndicator = readInt(ptr);
    trace(5, "msd->pseudorangeRateUncertaintyMetersPerSecond\n");
    msd->pseudorangeRateUncertaintyMetersPerSecond = readDouble(ptr);
    trace(5, "msd->receivedSvTimeNanos\n");
    msd->receivedSvTimeNanos = readLong(ptr);
    trace(5, "msd->receivedSvTimeUncertaintyNanos\n");
    msd->receivedSvTimeUncertaintyNanos = readLong(ptr);
    trace(5, "msd->snrInDb\n");
    msd->snrInDb = readDouble(ptr);
    trace(5, "msd->state\n");
    msd->state = readInt(ptr);
    trace(5, "msd->svid\n");
    msd->svid = readInt(ptr);
    trace(5, "msd->timeOffsetNanos\n");
    msd->timeOffsetNanos = readDouble(ptr);

    trace(5, "msd->hasAutomaticGainControlLevelDb\n");
    msd->hasAutomaticGainControlLevelDb = readInt(ptr);
    trace(5, "msd->hasCarrierCycles\n");
	msd->hasCarrierCycles = readInt(ptr);
    trace(5, "msd->hasCarrierFrequencyHz\n");
    msd->hasCarrierFrequencyHz = readInt(ptr);
    trace(5, "msd->hasCarrierPhase\n");
    msd->hasCarrierPhase = readInt(ptr);
    trace(5, "msd->hasCarrierPhaseUncertainty\n");
    msd->hasCarrierPhaseUncertainty = readInt(ptr);
    trace(5, "msd->hasSnrInDb\n");
    msd->hasSnrInDb = readInt(ptr);
  }
}
//static int            I4(unsigned char *p) {int            u; memcpy(&u,p,4); return u;}
int readInt(unsigned char **ptr) {
  int val;
  memcpy(&val, *ptr, sizeof(int));

  val=I4(*ptr);

  trace(5, "parsing int: %02X%02X%02X%02X -> %d\n",
      ((unsigned char*) *ptr)[0],
      ((unsigned char*) *ptr)[1],
      ((unsigned char*) *ptr)[2],
      ((unsigned char*) *ptr)[3],
      val);
  *ptr += sizeof(int);
  return val;
}

double readDouble(unsigned char **ptr) {
	double val;
	double val1;

	//double test = 0x7FF8000000000000;
	int i;
	unsigned char tempptr[8];
	for (i=0;i<8;i++)
	{
		tempptr[i]=*((*ptr)+(7-i));
	}
	memcpy(&val1,tempptr,sizeof(double));

	memcpy(&val, *ptr, sizeof(double));

	trace(5, "parsing double: %f\n", val);
	*ptr += sizeof(double);
	//printf("test double: %f\n", test);
	return val;
}

long long readLong(unsigned char **ptr) {
  long long val;
  memcpy(&val, *ptr, sizeof(long long));

  trace(5, "parsing long: %02X%02X%02X%02X %02X%02X%02X%02X -> %ld\n", 
      ((unsigned char*) *ptr)[0],
      ((unsigned char*) *ptr)[1],
	  ((unsigned char*) *ptr)[2],
      ((unsigned char*) *ptr)[3],
      ((unsigned char*) *ptr)[4],
	  ((unsigned char*) *ptr)[5],
	  ((unsigned char*) *ptr)[6],
      ((unsigned char*) *ptr)[7],
      val
      );
  *ptr += sizeof(long long);
  return val;
}

float readFloat(unsigned char **ptr) {
  float val;
  memcpy(&val, *ptr, sizeof(float));
  trace(5, "parsing float: %f\n", val);
  *ptr += sizeof(float);
  return val;
}
static int sync_andriod(unsigned char *buff, unsigned char data)
{
	buff[0] = buff[1]; buff[1] = data;
	return buff[0] == 0xB5 && buff[1] == 0X62;
}
static int checksum(unsigned char *buff, int len)
{
	char cka = 0, ckb = 0;
	int i;

	for (i = 2; i < len - 2; i++) {
		cka += buff[i]; ckb += cka;
	}
	return cka == buff[len - 2] && ckb == buff[len - 1];
}
extern int input_android(raw_t *raw, unsigned char data) {


	/* synchronize frame */
	if (raw->nbyte == 0) {
		if (!sync_andriod(raw->buff, data)) return 0;
		raw->nbyte = 2;
		return 0;
	}
	raw->buff[raw->nbyte++] = data;

	if (raw->nbyte == 6) {
		if ((raw->len = U2(raw->buff + 4) + 8) > MAXRAWLEN) {
			trace(2, "ubx length error: len=%d\n", raw->len);
			raw->nbyte = 0;
			return -1;
		}
	}
	if (raw->nbyte < 6 || raw->nbyte < raw->len) return 0;
	raw->nbyte = 0;
	if (!checksum(raw->buff, raw->len)) {
	 //	trace(2, "ubx checksum error: len=%d\n", raw->len);
	 //	return -1;
	}

	android_clockd_t cl;
	android_measurements_t ms;

	Clock_Mearsurement_Data(&cl, &ms, raw->buff);


	return convertObservationData(&raw->obs, &cl, &ms);

}

extern int input_androidf(raw_t *raw, FILE *fp) {

   	int i,data;

    trace(4,"input_androidf:\n");

    /* synchronize frame */
    if (raw->nbyte==0) {
        for (i=0;;i++) {
            if ((data=fgetc(fp))==EOF) return -2;
            if (sync_andriod(raw->buff,(uint8_t)data)) break;
            if (i>=4096) return 0;
        }
    }
    if (fread(raw->buff+2,1,4,fp)<4) return -2;
    raw->nbyte=6;

    if ((raw->len=U2(raw->buff+4)+8)>MAXRAWLEN) {
        trace(2,"ubx length error: len=%d\n",raw->len);
        raw->nbyte=0;
        return -1;
    }
    if (fread(raw->buff+6,1,raw->len-6,fp)<(size_t)(raw->len-6)) return -2;
	raw->nbyte=0;

	android_clockd_t cl;
	android_measurements_t ms;

	Clock_Mearsurement_Data(&cl, &ms, raw->buff);
    /* decode android raw message */
	return convertObservationData(&raw->obs, &cl, &ms);

}